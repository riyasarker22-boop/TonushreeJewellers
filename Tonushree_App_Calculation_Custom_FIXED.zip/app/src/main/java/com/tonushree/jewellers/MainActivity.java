package com.tonushree.jewellers;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText price, bhori, ana, roti, point, customBad;
    Spinner karat;
    TextView result;

    final String[] ks = {
        "22K - প্রতি ভরিতে ১.৫ আনা বাদ",
        "21K - প্রতি ভরিতে ২ আনা বাদ",
        "20K - প্রতি ভরিতে ৪ আনা বাদ",
        "18K - প্রতি ভরিতে ৬ আনা বাদ",
        "Custom - নিজের মতো বাদ"
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("তনুশ্রী জুয়েলার্স\nপুরাতন স্বর্ণ হিসাব");
        title.setTextSize(25);
        title.setTextColor(Color.rgb(150, 105, 25));
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        price = field("প্রতি ভরি মূল্য (৳)");
        root.addView(price);

        karat = new Spinner(this);
        karat.setAdapter(new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                ks
        ));
        root.addView(karat);

        customBad = field("Custom বাদ (প্রতি ভরিতে কত আনা?)");
        customBad.setVisibility(View.GONE);
        root.addView(customBad);

        karat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                customBad.setVisibility(position == 4 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        TextView w = new TextView(this);
        w.setText("ওজন");
        w.setTextSize(18);
        root.addView(w);

        bhori = field("ভরি");
        ana = field("আনা");
        roti = field("রতি");
        point = field("পয়েন্ট");

        root.addView(bhori);
        root.addView(ana);
        root.addView(roti);
        root.addView(point);

        Button btn = new Button(this);
        btn.setText("হিসাব করুন");
        root.addView(btn);

        result = new TextView(this);
        result.setTextSize(20);
        result.setPadding(0, 30, 0, 0);
        root.addView(result);

        btn.setOnClickListener(v -> calc());

        setContentView(root);
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    double d(EditText e) {
        try {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) return 0;
            return Double.parseDouble(s);
        } catch (Exception x) {
            return 0;
        }
    }

    void calc() {
        double p = d(price);
        double b = d(bhori);
        double a = d(ana);
        double r = d(roti);
        double pt = d(point);

        // 1 ভরি = 16 আনা, 1 আনা = 6 রতি, 1 রতি = 10 পয়েন্ট
        double totalPoints = b * 16 * 6 * 10
                + a * 6 * 10
                + r * 10
                + pt;

        double grossAna = totalPoints / 60.0;

        if (p <= 0) {
            Toast.makeText(this, "প্রতি ভরি মূল্য লিখুন", Toast.LENGTH_SHORT).show();
            return;
        }

        if (grossAna <= 0) {
            Toast.makeText(this, "ওজন লিখুন", Toast.LENGTH_SHORT).show();
            return;
        }

        double badPerBhori = 1.5;
        int pos = karat.getSelectedItemPosition();

        if (pos == 1) badPerBhori = 2.0;
        else if (pos == 2) badPerBhori = 4.0;
        else if (pos == 3) badPerBhori = 6.0;
        else if (pos == 4) {
            badPerBhori = d(customBad);
            if (badPerBhori < 0 || badPerBhori > 16) {
                Toast.makeText(this, "Custom বাদ ০ থেকে ১৬ আনার মধ্যে দিন", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        show(p, grossAna, badPerBhori);
    }

    void show(double p, double grossAna, double badPerBhori) {
        // বাদটি মোট ওজন থেকে স্থির আনা নয়; প্রতি ভরির অনুপাতে বাদ হবে।
        double deductedAna = grossAna * (badPerBhori / 16.0);
        double netAna = Math.max(0, grossAna - deductedAna);
        double value = p * (netAna / 16.0);

        result.setText(String.format(
                Locale.US,
                "মূল ওজন: %.2f আনা\n" +
                "খাত/বাদ: প্রতি ভরিতে %.2f আনা\n" +
                "মোট বাদ: %.2f আনা\n" +
                "বাদ দেওয়ার পর: %.2f আনা\n\n" +
                "প্রাপ্য মূল্য: ৳%.2f",
                grossAna,
                badPerBhori,
                deductedAna,
                netAna,
                value
        ));
    }
}
