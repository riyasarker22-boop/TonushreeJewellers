package com.tonushree.jewellers;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {

    EditText price, customAna, bhori, ana, roti, point;
    Spinner karat;
    LinearLayout customBox;
    TextView result;

    final double[] KHAT = {1.5, 2.0, 4.0, 6.0};
    final String[] OPTIONS = {
            "22K — ১.৫ আনা বাদ",
            "21K — ২ আনা বাদ",
            "20K — ৪ আনা বাদ",
            "18K — ৬ আনা বাদ",
            "Custom — নিজের খাত"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        price = findViewById(R.id.price);
        customAna = findViewById(R.id.customAna);
        bhori = findViewById(R.id.bhori);
        ana = findViewById(R.id.ana);
        roti = findViewById(R.id.roti);
        point = findViewById(R.id.point);
        karat = findViewById(R.id.karat);
        customBox = findViewById(R.id.customBox);
        result = findViewById(R.id.result);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                OPTIONS
        );
        karat.setAdapter(adapter);

        karat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                customBox.setVisibility(position == 4 ? View.VISIBLE : View.GONE);
                calculate();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        findViewById(R.id.calc).setOnClickListener(v -> calculate());
        calculate();
    }

    private double value(EditText e) {
        try {
            String s = e.getText().toString().trim();
            return s.isEmpty() ? 0 : Double.parseDouble(s);
        } catch (Exception ex) {
            return 0;
        }
    }

    private void calculate() {
        double pricePerBhori = value(price);
        double b = value(bhori);
        double a = value(ana);
        double r = value(roti);
        double p = value(point);

        double totalAna = b * 16.0 + a + r / 6.0 + p / 60.0;

        int pos = karat.getSelectedItemPosition();
        double khat = (pos == 4) ? Math.max(0, Math.min(16, value(customAna))) : KHAT[pos];

        double effectiveRate = pricePerBhori * (16.0 - khat) / 16.0;
        double finalPrice = effectiveRate * totalAna / 16.0;

        String label = pos == 4 ? "Custom" : OPTIONS[pos].substring(0, 2);

        result.setText(String.format(
                Locale.US,
                "মূল ওজন: %.4f ভরি\n" +
                "আনা সমমান: %.4f আনা\n\n" +
                "ক্যারেট / খাত: %s\n" +
                "খাত: %.2f আনা\n\n" +
                "খাত বাদে প্রতি ভরির মূল্য: ৳%,.2f\n\n" +
                "প্রাপ্য মূল্য: ৳%,.2f",
                totalAna / 16.0,
                totalAna,
                label,
                khat,
                effectiveRate,
                finalPrice
        ));
    }
}
