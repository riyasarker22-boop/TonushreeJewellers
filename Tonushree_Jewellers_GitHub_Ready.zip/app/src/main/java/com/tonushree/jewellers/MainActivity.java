package com.tonushree.jewellers;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText price, bhori, ana, roti, point;
    Spinner karat;
    TextView result;
    final String[] ks={"22K - ১.৫ আনা বাদ","21K - ২ আনা বাদ","20K - ৪ আনা বাদ","18K - ৬ আনা বাদ","Custom - নিজের মতো বাদ"};

    public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,40,32,32);
        TextView title=new TextView(this); title.setText("তনুশ্রী জুয়েলার্স\nপুরাতন স্বর্ণ হিসাব"); title.setTextSize(25); title.setTextColor(Color.rgb(150,105,25)); title.setGravity(17);
        root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        price=field("প্রতি ভরি মূল্য (৳)"); root.addView(price);
        karat=new Spinner(this); karat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ks)); root.addView(karat);
        TextView w=new TextView(this); w.setText("ওজন"); w.setTextSize(18); root.addView(w);
        bhori=field("ভরি"); ana=field("আনা"); roti=field("রতি"); point=field("পয়েন্ট"); root.addView(bhori);root.addView(ana);root.addView(roti);root.addView(point);
        Button btn=new Button(this); btn.setText("হিসাব করুন"); root.addView(btn);
        result=new TextView(this); result.setTextSize(20); result.setPadding(0,30,0,0); root.addView(result);
        btn.setOnClickListener(v->calc());
        setContentView(root);
    }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setInputType(2|8192); return e; }
    double d(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
    void calc(){
        double p=d(price), b=d(bhori), a=d(ana), r=d(roti), pt=d(point);
        double total=b*16*6*10 + a*6*10 + r*10 + pt; // point = 1/10 roti
        double grossAna=total/(6*10);
        double badAna=1.5;
        if(karat.getSelectedItemPosition()==1) badAna=2;
        else if(karat.getSelectedItemPosition()==2) badAna=4;
        else if(karat.getSelectedItemPosition()==3) badAna=6;
        else if(karat.getSelectedItemPosition()==4){
            final EditText custom=field("কত আনা বাদ?");
            new AlertDialog.Builder(this).setTitle("Custom খাত").setView(custom).setPositiveButton("ঠিক আছে",(d,w)->show(p,grossAna,Double.parseDouble(custom.getText().toString()))).show();
            return;
        }
        show(p,grossAna,badAna);
    }
    void show(double p,double grossAna,double badAna){
        double netAna=Math.max(0,grossAna-badAna);
        double val=p*(netAna/16.0);
        result.setText(String.format(Locale.US,"মূল ওজন: %.2f আনা\nখাত/বাদ: %.2f আনা\nবাদ দেওয়ার পর: %.2f আনা\n\nপ্রাপ্য মূল্য: ৳%.2f",grossAna,badAna,netAna,val));
    }
}
